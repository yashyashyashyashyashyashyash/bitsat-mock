const questions = [
  {
    question: "A lead bullet penetrates into a solid object and melts. Assuming that 50% of its kinetic energy was used to heat it, the initial speed of the bullet is approximately:",
    options: ["100 m/s", "≈ 490 m/s", "520 m/s", "360 m/s"],
    answer: 1,
    explanation: "Using KE and heat energy relation: (1/4)v^2 = cΔT + L. Solving gives v ≈ 490 m/s."
  },
  {
    question: "The dimensional formula for angular momentum is:",
    options: ["[M]L²T⁻²", "[ML]T⁻¹", "[M]L²T⁻¹", "[M⁰L²T⁻²]"],
    answer: 2,
    explanation: "L = Iω; I = mr², ω = rad/s → [M]L²T⁻¹"
  }
];

export default questions;