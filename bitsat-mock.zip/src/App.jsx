import React, { useState } from "react";
import questions from "./questions";

export default function App() {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const currentQuestion = questions[current];

  const handleSubmit = () => {
    if (selected === currentQuestion.answer) setScore(score + 1);
    setSubmitted(true);
  };

  const handleNext = () => {
    if (current < questions.length - 1) {
      setCurrent(current + 1);
      setSelected(null);
      setSubmitted(false);
    } else {
      setShowResult(true);
    }
  };

  if (showResult) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-4">
        <h1 className="text-2xl mb-4">Test Completed</h1>
        <p>Your Score: {score} / {questions.length}</p>
        <div className="mt-4 space-y-4">
          {questions.map((q, i) => (
            <div key={i} className="p-2 border rounded bg-gray-800">
              <p><strong>Q{i+1}:</strong> {q.question}</p>
              <p><strong>Correct:</strong> {q.options[q.answer]}</p>
              {q.explanation && <p className="text-sm text-green-400"><strong>Why?</strong> {q.explanation}</p>}
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <h2 className="text-xl mb-4">Question {current + 1} of {questions.length}</h2>
      <p className="mb-4">{currentQuestion.question}</p>
      <div className="space-y-2">
        {currentQuestion.options.map((option, idx) => (
          <div
            key={idx}
            className={\`p-2 rounded border cursor-pointer \${selected === idx ? "bg-blue-700" : "bg-gray-700"}\`}
            onClick={() => setSelected(idx)}
          >
            {option}
          </div>
        ))}
      </div>
      <div className="mt-4">
        {!submitted ? (
          <button onClick={handleSubmit} disabled={selected === null} className="bg-blue-600 px-4 py-2 rounded">
            Submit
          </button>
        ) : (
          <button onClick={handleNext} className="bg-green-600 px-4 py-2 rounded">Next</button>
        )}
      </div>
    </div>
  );
}
